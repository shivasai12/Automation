///<reference types="Cypress"/>
///<reference types="cypress-xpath"/>
import 'cypress-xpath'
import 'cypress-wait-until'
import 'cypress-plugin-tab'
import testData from './profile'



describe("My first test Suite", ()=>{
   /* let data;
    before(()=>{
       
        cy.fixture('example').then(function(data1){
            data= data1[0]
        })
    
       
    })*/
    
    testData.forEach((data)=>{
    it('My first test case', ()=>{

       cy.visit(Cypress.env("url1"))
        
        cy.clickDropDown('Region')
        console.log()
        cy.selectValue(data.region).should('have.text', data.region)
        cy.clickDropDown('Sub-Region')
        cy.selectValue(data.business_unit).should('have.text', data.business_unit)

        cy.clickDropDown('Site')
        cy.get("input[placeholder='Search']").filter(':visible').type(data.site)
        cy.selectValue(data.site).should('have.text', data.site)

        cy.clickDropDown('Chassis ID')
        cy.get("input[placeholder='Search']").filter(':visible').type(data.chassis_id)
        cy.selectValue(data.chassis_id).should('have.text', data.chassis)

          cy.clickDropDown('SKU Number')
          cy.get("input[placeholder='Search']").filter(':visible').type(data.sku_num)
          cy.selectValue(data.sku_num).should('have.text', data.sku_num)
        
          cy.screenshot()
        cy.contains('APPLY').click()
        cy.screenshot()

        cy.get("div[col-id='line_of_business']", {timeout:20000}).should('be.visible')
        cy.get("div[col-id='line_of_business']").should('contain.text', 'Precision Desktops')

        cy.get("div[col-id='family_parent']").each(($el, index, list)=>{
            if(!$el.text().includes('Family Parent')){
                cy.get("div[col-id='family_parent']").eq(index).should('contain.text', 'Pearl')
            }
        })
        cy.screenshot()

        
        
        //cy.validateText('chassis_id','12420','Chassis ID')
        cy.validateText('module', data.module_id, 'Module Name')
        cy.validateText('chassis',data.chassis, 'Chassis Name')
        cy.validateText('option_code',data.option_code, 'Option ID')
        cy.validateText('sku_num',data.sku_num,'SKU Number')
        
        


       
       /*  cy.request({
            method: 'POST',
            url:"https://recommendationenginedevapi.cfd.isus.emc.com/V1/Get_recommendations",
            
            headers:{
                'content-type':'application/json'
            },
            body:{
                "Region": "DAO",
                "BusinessUnitId": 11,
                "ChassisId": 12420,
                "ModuleId": 3,
                "SkuNum": "370-AFHS ",
                "option_code": "G2LQ6PN"
            }
        }).then(function(response){
            expect(response.body).have.property('Region', "DAO")
            expect(response.body).to.deep.equal({
                "base_sku_num": data.SkuNum,
                "business_unit": data.business_unit,
                "chassis_id": data.chassis_id,
            })
        })
        
      //  cy.get(".ag-row > [aria-colindex='3']").should('contain.text', '12429')
        */


        
       // cy.waitUntil(()=>.then($el=>$el.length===0))
    })
})
})