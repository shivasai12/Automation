///<reference types="Cypress"/>
///<reference types="cypress-xpath"/>
describe("My first test Suite", ()=>{
    
    let data;
    before(()=>{
        cy.fixture('example').then(function(data1){
            data= data1
        })
    })
    
    it('My first test case', ()=>{
        
        //cy.loadFixture('cypress/fixtures/example.json')
        cy.request({
            method: 'POST',
            url:'https://recommendationenginedevapi.cfd.isus.emc.com/V1/Get_recommendations',
            timeout: 50000,
            
            
            body:{
                "Region": "DAO",
                "BusinessUnitId": 11,
                "ChassisId": 12420,
                "ModuleId": 3,
                "SkuNum": "370-AFHS",
                "option_code": "G2LQ6PN"
            }
        }).then(function(response){
            expect(response.body[0].business_unit).to.eq(data.BusinessUnitId)
            console.log(response.body[0].business_unit)
            cy.writeFile('cypress/fixtures/example.json', response.body)
            
        })
        
      //  cy.get(".ag-row > [aria-colindex='3']").should('contain.text', '12429')
        


        
       // cy.waitUntil(()=>.then($el=>$el.length===0))*/
    })
})