///<reference types="Cypress"/>
///<reference types="cypress-xpath"/>
import 'cypress-xpath'
import 'cypress-wait-until'


describe("My first test Suite", ()=>{
    let data;
    before(()=>{
        cy.fixture('example').then(function(data1){
            data= data1
        })
    })
    
    it('My first test case', ()=>{
        cy.visit(Cypress.env("url"))
        

        cy.get(":nth-child(1) > label ~").click()
        cy.get(".scrollable-content li label:contains('"+data.Region+"')").click().should('have.text', data.Region)
        cy.get(':nth-child(2)>label~').click()
        cy.get(".scrollable-content li label:contains('"+data.BusinessUnitId+"')").click().should('have.text', data.BusinessUnitId)

        cy.get(':nth-child(3)>label~').click()
        cy.get(".scrollable-content li label:contains('"+data.Site+"')").click().should('have.text', data.Site)

        cy.wait(30000).get(':nth-child(4)>label~').click()
        cy.get("input[placeholder='Search']").filter(':visible').type(data.ChassisId)
        cy.get(".scrollable-content li label:contains('"+data.ChassisId+"')").click()
                                                        .should('have.text', data.ChassisId)

          cy.wait(15000).get(':nth-child(5)>label~').click()
          cy.get("input[placeholder='Search']").filter(':visible').type(data.SkuNum)
          cy.get(".scrollable-content li label:contains('"+data.SkuNum+"')").click()
                                                        .should('have.text', data.SkuNum)
        
        cy.contains('APPLY').click()

        cy.get('#cell-58', {timeout:20000}).should('be.visible')
        cy.get('#cell-58').should('contain.text', 'Precision Desktops')

        cy.get("div[col-id='family_parent']:nth-of-type(2)").each(($el, index, list)=>{
            if(!$el.text().includes('Family Parent')){
                cy.get("div[col-id='family_parent']:nth-of-type(2)").eq(index).should('contain.text', 'Pearl')
            }
        })

        cy.get("div[col-id='chassis_id']").each(($el, index, list)=>{
            if(!$el.text().includes('Chassis ID')){
                cy.get("div[col-id='chassis_id'] ").eq(index).should('contain.text', '12420')
            }
        })
        //cy.validateText('chassis_id','12420','Chassis ID')
        cy.validateText('chassis_internal_name', 'Precision 7920 Rack (Pearl)', 'Chassis Name')
        cy.validateText('option_code','15TB24L', 'Option ID')
        cy.validateText('sku_num','370-ADTB','SKU Number')
        cy.validateText('sku_long_name','1.5TB 24x64GB DDR4 2666MHz LRDIMM ECC Memory', 'External Description')
        cy.validateText('lead_time','7(+5 days)', 'Lead Time')
        cy.validateText('module_internal_name', 'Memory', 'Module Name')
      //  cy.get(".ag-row > [aria-colindex='3']").should('contain.text', '12429')
        


        
       // cy.waitUntil(()=>.then($el=>$el.length===0))
    })
})