// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })


Cypress.Commands.add('validateText', (colid, expctText, header) => { 
    cy.get("div[col-id='"+colid+"']").each(($el, index, list)=>{
        if(!$el.text().includes(header)){
            cy.get("div[col-id='"+colid+"']").eq(1).should('contain.text', expctText)
        }
    })
})

Cypress.Commands.add('clickDropDown', (colid) => { 
    cy.get(".sample-box>angular2-multiselect span:contains('Select "+colid+"')").click()
})

Cypress.Commands.add('selectValue', (colid) => { 
    cy.get("ul li:contains('"+colid+"')").click()
})

Cypress.Commands.add('loadFixture', (savePath) => {
    cy.request({
      method: 'post',
      url: Cypress.env("api"),
      timeout: 50000
    }).then(res => {
      cy.log('Fixture loaded from API');

      cy.writeFile(savePath, res.body);
      cy.log('Fixture written to disk');
    });
  });